-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cloud
-- ------------------------------------------------------
-- Server version	8.0.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add four',7,'add_four'),(26,'Can change four',7,'change_four'),(27,'Can delete four',7,'delete_four'),(28,'Can view four',7,'view_four'),(29,'Can add one',8,'add_one'),(30,'Can change one',8,'change_one'),(31,'Can delete one',8,'delete_one'),(32,'Can view one',8,'view_one'),(33,'Can add three',9,'add_three'),(34,'Can change three',9,'change_three'),(35,'Can delete three',9,'delete_three'),(36,'Can view three',9,'view_three'),(37,'Can add two',10,'add_two'),(38,'Can change two',10,'change_two'),(39,'Can delete two',10,'delete_two'),(40,'Can view two',10,'view_two');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(7,'home','four'),(8,'home','one'),(9,'home','three'),(10,'home','two'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES (1,'contenttypes','0001_initial','2023-05-23 07:44:09.502077'),(2,'auth','0001_initial','2023-05-23 07:44:11.213520'),(3,'admin','0001_initial','2023-05-23 07:44:11.693691'),(4,'admin','0002_logentry_remove_auto_add','2023-05-23 07:44:11.732963'),(5,'admin','0003_logentry_add_action_flag_choices','2023-05-23 07:44:11.772115'),(6,'contenttypes','0002_remove_content_type_name','2023-05-23 07:44:12.121727'),(7,'auth','0002_alter_permission_name_max_length','2023-05-23 07:44:12.323918'),(8,'auth','0003_alter_user_email_max_length','2023-05-23 07:44:12.429238'),(9,'auth','0004_alter_user_username_opts','2023-05-23 07:44:12.462140'),(10,'auth','0005_alter_user_last_login_null','2023-05-23 07:44:12.630056'),(11,'auth','0006_require_contenttypes_0002','2023-05-23 07:44:12.644042'),(12,'auth','0007_alter_validators_add_error_messages','2023-05-23 07:44:12.683831'),(13,'auth','0008_alter_user_username_max_length','2023-05-23 07:44:12.845116'),(14,'auth','0009_alter_user_last_name_max_length','2023-05-23 07:44:12.985595'),(15,'auth','0010_alter_group_name_max_length','2023-05-23 07:44:13.053285'),(16,'auth','0011_update_proxy_permissions','2023-05-23 07:44:13.089900'),(17,'auth','0012_alter_user_first_name_max_length','2023-05-23 07:44:13.285695'),(18,'home','0001_initial','2023-05-23 07:44:13.628130'),(19,'sessions','0001_initial','2023-05-23 07:44:13.745805'),(20,'home','0002_auto_20230523_1623','2023-05-23 08:23:51.900849'),(21,'home','0003_four_one_three_two','2023-05-23 08:24:06.629162');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `four`
--

DROP TABLE IF EXISTS `four`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `four` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(600) NOT NULL,
  `an` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `four`
--

LOCK TABLES `four` WRITE;
/*!40000 ALTER TABLE `four` DISABLE KEYS */;
INSERT INTO `four` (`id`, `title`, `an`) VALUES (1,'12. (简答题)总结OpenStack各服务模块之间是如何协同工作的。','OpenStack的各个服务之间通过统一的REST风格的API调用，实现系统的松耦合。'),(2,'13. (简答题)OpenStack是什么？','OpenStack是构建云操作系统的框架，是一个指在为公有云及私有云的建设与管理提供软件的开源项目，其包含数量众多的外围组件，集成并管理各类硬件设备，并承载各类上层应用与服务，最终形成一个完整的、功能强大的云计算系统。OpenStack自身的准确定位，是一个云操作系统框架。'),(3,'14. (简答题)总结OpenStack的主要组件及其功能。','Nova是OpenStack的控制器，支持OpenStack云内的实例的生命周期所需的所有活动处理。Nova作为管理平台管理着OpenStack云里的计算资源和扩展需求。Swift提供对象存储服务，允许对文件进行存储或者检索，但不通过挂载文件服务器上目录的方式来实现。Swift为OpenStack提供了分布式的、最终一致的虚拟对象存储。Glance提供了一个虚拟磁盘镜像的目录和存储仓库，可以提供对虚拟机镜像的存储和检索。这些磁盘镜像广泛应用于Nova组件之中。Glance能进行多个数据中心的镜像管理和租户私有镜像管理。Keystone为OpenStack上的所有服务提供身份认证和授权。Neutron是OpenStack中提供网络服务的核心组件，基于软件定义网络的思想，实现软件化的网络资源管理，在实现上充分利用了Linux操作系统中各种网络相关技术，支持第三方插件。'),(4,'3. (简答题)RAID 2.0做出了什么样的改进，对存储性能有哪些提升？','把大容量机械硬盘先按照固定的容量切割成多个更小的分块，块长度通常为64MB，RAID组建立在这些小分块上，称为分块组。此时硬盘间不再组成传统的RAID关系，而是组成可能具有更多硬盘数量的硬盘组，每个硬盘上不同的分块可与此硬盘组上不同硬盘上的分块组成不同RAID类型的分块组，这样一个硬盘上的分块可以属于多个RAID类型的多个分块组。快速重构：存储池内所有硬盘参与重构，相对传统RAID重构速度大幅提升；自动负载均衡：RAID 2.0使得各硬盘均衡分担负载，不再有热备份盘，提升了系统的性能和硬盘的可靠性；系统性能提升：LUN基于分块组创建，可以不受传统RAID硬盘数量的限制分布在更多的物理硬盘上，因而系统性能随硬盘I/O带宽增加得以有效提升；自愈合：当出现硬盘预警时，无须热备份盘，无须立即更换故障盘，系统可快速重构，实现自愈合。'),(5,'4. (简答题)列举常见的RAID技术，并比较说明不同RAID技术的区别。','RAID 0也称为条带化，其原理是将多个物理磁盘合并成一个大的逻辑磁盘。它代表了所有RAID级别中效率最高的存储性能，不具有冗余，不能并行I/O，但速度最快。RAID 1目的是最大限度地保证用户数据的可用性和可修复性。RAID 1的原理是把用户写入磁盘的数据百分之百地自动复制到另外一个磁盘上。RAID 5使用奇偶校验来进行校验和纠错。RAID 5不对存储的数据进行备份，而是把数据和相对应的奇偶校验信息存储到组成RAID 5的各个磁盘上，并且数据和相对应的奇偶校验信息分别存储于不同的磁盘上。当RAID 5的一个磁盘数据损坏后，利用剩下的数据和相应的奇偶校验信息可以恢复被损坏的数据。RAID 6是为了进一步加强数据保护而设计的一种RAID级别。与RAID 5相比，RAID 6增加了第二种独立的奇偶校验信息块。相当于每个数据块都有两个校验保护屏障。'),(6,'21. (简答题)简述总线型、星型和环型拓扑结构的优缺点。','总线型：（1）结构简单，可扩充，性能好；（2）网络的可靠性高，节点间响应速度快，共享资源能力强；（3）网络的成本低，设备投入量少，安装使用方便；（4）总线的性能和可靠性对网络有很大影响。星型：（1）建网容易，扩充性好，管理方便；（2）中央节点是整个系统的瓶颈，如果中央节点出现故障，则整个网络将瘫痪。环形：环形网结构简单，传输时延确定，但是环中每个节点与连接节点之间的通信线路都会成为网络可靠性的风险点，一旦出现故障就会影响整个网络的正常运行。对于环形网，网络节点的加入和退出、环路的维护和管理都比较复杂。'),(7,'22. (简答题)南北流量和东西流量有什么区别？','客户端和负载均衡器之间的网络流量被称为南北流量。不同服务器之间的流量或数据中心与不同数据中心之间的网络流量被称为东西流量。'),(8,'23. (简答题)简述通信子网与资源子网的主要工作。','资源子网由主机、终端和外设、各种软件资源与信息资源组成，主要负责全网的信息处理，为网络用户提供网络服务和资源共享功能。通信子网实际上就是分组交换网，由节点交换机、通信线路与其他通信设备组成，主要负责全网的数据通信，为网络用户提供数据传输、转接、加工和变换等通信处理工作。'),(9,'24. (简答题)SDN相对于传统网络有什么优势？','首先，数据与控制解耦合使得应用升级与设备更新换代相互独立，加快了新应用的快速部署；其次，网络抽象简化了网络模型，将运营商从繁杂的网络管理中解放出来，能够更加灵活地控制网络；最后，控制逻辑中心化使用户和运营商等可以通过控制器获取全局网络信息，从而优化网络，提升网络性能。'),(10,'3. (简答题)内存虚拟化与存储虚拟化有何不同？','内存虚拟化技术把物理机的真实物理内存统一管理，包装成多个虚拟的物理内存分别供若干台虚拟机使用，使得每台虚拟机拥有各自独立的内存空间。在服务器虚拟化中，由于内存是虚拟机最频繁访问的设备，因此内存虚拟化与CPU 虚拟化具有同等重要的地位。存储虚拟化可以使逻辑存储单元在广域网范围内整合，并且可以不需要停机就从一个磁盘阵列移动到另一个磁盘阵列上。此外，存储虚拟化还可以根据用户的实际使用情况来分配存储资源。'),(11,'4. (简答题)什么是NUMA？NUMA在虚拟化中是如何工作的？','NUMA中文全称为非统一内存访问，是一种可以提高数据读/写速度的技术。设计者就把内存平均地绑定到每个CPU上，这样就可以避免共享北桥而出现的拥塞。使用了NUMA后，它会把CPU和与其绑定的内存当作一个NUMA节点，每个节点都有自己的内部CPU、总线和内存。如果跨节点进行访问，则需通过CPU之间的互联对应到虚拟机中。使用NUMA技术可以让虚拟机使用同一NUMA节点上的硬件资源，以提高虚拟机的响应速度。'),(12,'5. (简答题)简述虚拟化与半虚拟化的联系与区别。','半虚拟化又称类虚拟化。半虚拟化是通过在源代码级别修改指令以回避虚拟化漏洞的方式来使VMM能够对物理资源实现虚拟化。全虚拟化通过二进制代码翻译在二进制代码级别上避免虚拟化漏洞。半虚拟化采取的是另一种思路，即修改操作系统内核的代码（即API级），使得操作系统内核完全避免这些难以虚拟化的指令。'),(13,'6. (简答题)什么是虚拟化？虚拟化有哪些特点？','虚拟化是表示计算机资源的抽象方法，通过虚拟化可以用与访问抽象前资源一致的方法访问抽象后的资源。这种资源的抽象方法并不受实现、地理位置或底层资源的物理配置的限制。首先，虚拟计算机最主要的作用是能够充分发挥高性能计算机的闲置资源的能力，以达到即使不购买硬件也能提高服务器利用率的目的；同时，也能够完成客户系统应用的快速交付与快速恢复。这是公众对虚拟计算机最基本与直观的认识。其次，虚拟化技术正逐渐在企业管理与业务运营中发挥至关重要的作用，不仅能够实现服务器与数据中心的快速部署与迁移，还能体现出其透明行为管理的特点。'),(14,'17. (简答题)数字证书的主要原理是什么？有哪些用途?','数字证书是带数字签名的数据结构，一般由第三方证书颁发机构来签发。数字证书通常携带证书拥有者的身份信息，该信息已由CA核实；证书拥有者的公钥；CA颁发的证书及CA的数字签名，数字签名中用CA的私钥对证书的摘要进行了加密；其他还有诸如有效期这类的相关信息。CA一般是外界信任的权威机构，其公钥通常是公开的，外界可用CA的公钥来核实CA数字签名的真伪，如果为真，说明CA已经核实了证书拥有者身份的真实性，从而间接地核实了该证书的真实性和有效性。'),(15,'18. (简答题)从功能的角度考虑，基本云架构主要有哪几个大类？分别与哪些功能相匹配？','负载分布架构、资源池架构、动态可扩展架构、弹性资源容量架构、服务负载均衡架构、云爆发架构、弹性磁盘供给架构和冗余存储架构。与负载均衡、弹性伸缩等功能匹配。'),(16,'19. (简答题)一个云计算系统如果要正常运行，哪些机制是必不可少的？','云基础设施机制、云管理机制、云安全机制和基本云架构。'),(17,'17. (简答题)如何从三元认识论的角度理解云计算？','云计算服务代表一种新的商业模式，SaaS、PaaS和IaaS是这种商业模式的3种表现形式。对任何一种商业模式而言，除了理论上可行之外，还要保证实践上可行。因此，伴随着云计算服务理念的发展，云计算也形成了一整套的软件架构与技术实现机制，而我们常常听到的云平台就是这套机制的具体体现。从计算模式的角度而言，云计算最早的出身，应该是超大规模分布式计算。云计算作为一种计算模式，其计算边界既由上层的经济因素所决定，也由下层的技术因素所决定。经济因素自上而下决定这种计算模式的商业形态，技术因素自下而上决定这种计算模式的技术形态。云计算最终的实现方式需要新一代的软/硬件技术推动，即目前流行的数据中心，并且朝着软件定义的数据中心演进。数据中心是云计算实现的最终归属，包括全方位的计算、存储和通信需求。随着数据中心的运营，大家开始碰到一系列共同的问题，包括硬件资源利用率、扩展性、自动化管理等。硬件的更新换代需要经年累月，通常很难满足快速发展的业务需求，软件定义才是现实可行的出路。因此，软件定义的数据中心迅速成为IT产业的热门关键词。'),(18,'18. (简答题)云计算按照运营模式分可分哪几类？哪一类能提供较高的安全和私密等保证？','可分为公有云：一类能被公开访问的云环境，通常由第三方云服务提供商拥有；私有云：企业和其他社团组织不对公众开放，为本企业或社团组织提供云服务（IT资源）的数据中心；  社区云：由一个社区，而不是一家企业所拥有的云平台，一般隶属于某个企业集团、机构联盟或行业协会，一般也服务于同一个集团、联盟或协会；混合云：用户可以通过一种可控的方式部分拥有，部分与他人共享。企业可以利用公有云的成本优势，将非关键的应用部分运行在公有云上，同时将安全性要求更高、关键性更强的主要应用通过内部的私有云提供服务。私有云能提供较高的安全和私密等保证。'),(19,'19. (简答题)云计算与传统的主机计算有什么共同点和区别？','云计算与主机计算实际上存在许多的共同点，例如都是集中式管理和按用量计费。不过云计算与主机计算的区别也很大，其中一个重要的区别是面向的用户群体不同。主机计算的用户通常是大型机构，并为关键软件所准备，如人口普查、消费统计、企业资源计划、财务交易等；而云计算则面向大众，可以运行各种各样的大、中、小型软件。另外，主机计算的处理单元通常是单一的大型主机，而云计算的处理单元则一般由众多的IT资源以集群方式构成，处理能力要远大于早期的单一主机。'),(20,'20. (简答题)开源软件、自由软件和免费软件的区别与联系是什么？','开源软件是一种版权持有人为任何人提供学习、修改和分发权利，并公布源代码的计算机软件。自由软件是一种用户可以自由地运行、复制、分发、学习、修改并改进的软件。免费软件是一种开发者拥有版权，保留控制发行、修改和销售权利的免费计算机软件，通常不发布源代码，以防用户修改源代码。广义上认为，自由软件是开源软件的一个子集，自由软件的定义比开源软件更严格。同时，开源软件要求软件发行时附上源代码，并不一定免费；同样免费软件只是软件免费提供给用户使用，并不一定开源。'),(21,'21. (简答题)云计算的有哪些特点？使用云计算有什么好处？','特点：按需自助服务、广泛的网络接入、资源池化、快速弹性伸缩、可计量服务优势：节省成本、数据可以随时随地地即时访问、提高适应能力，灵活扩展IT需求、统一平台'),(22,'22. (简答题)云计算技术包含的关键技术（称云使能技术）有哪些？','包括宽带网络和Internet架构、数据中心技术、虚拟化技术、Web技术、多租户技术、服务技术。'),(23,'23. (简答题)云计算的服务类型有哪三种？亚马逊的AWS和微软的Windows Azure各属于哪一种？','IaaS（基础设施即服务）、PaaS（平台即服务）和SaaS（软件即服务）。亚马逊的AWS属于IaaS，Windows Azure属于PaaS。'),(24,'24. (简答题)云计算的定义是什么？','云计算是一种计算模式，在这种模式下，动态可扩展而且通常是虚拟化的资源通过互联网以服务的形式提供出来。终端用户不需要了解“云”中基础设施的细节，不必具有相应的专业知识，也无须直接进行控制，而只需关注自己真正需要什么样的资源，以及如何通过网络来得到相应的服务。');
/*!40000 ALTER TABLE `four` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `one`
--

DROP TABLE IF EXISTS `one`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `one` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `A` varchar(256) NOT NULL,
  `B` varchar(256) NOT NULL,
  `C` varchar(256) NOT NULL,
  `D` varchar(256) NOT NULL,
  `an` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `one`
--

LOCK TABLES `one` WRITE;
/*!40000 ALTER TABLE `one` DISABLE KEYS */;
INSERT INTO `one` (`id`, `title`, `A`, `B`, `C`, `D`, `an`) VALUES (1,'在OpenStack平台中，（ ）用于定义可以访问资源的集合。','A. Role','B. Domain','C. User','D. Project',' D:Project; '),(2,'在OpenStack平台中，下列哪个组件负责支持实例的所有活动并且管理所有实例的生命周期?','A. Nova','B. Glance','C. Swift','D. Neutron',' A:Nova; '),(3,'在OpenStack平台中，（ ）可以在路由上对网络流量包过滤，增强网络安全性。','A. Securet Group','B. ML2','C. LBaas','D. FWaaS',' D:FWaaS; '),(4,'OpenStack组件不包括（ ）。','A. Swift','B. Nova','C. Keystone','D. EC2',' D:EC2; '),(5,'OpenStack中Cinder组件不提供的基本功能是（ ）。','A. 提供高性能的文件系统','B. 提供持久的存储介质，并可以将其在虚拟机之间传递','C. 提供基本的块存储管理功能','D. 通过iSCSI、FC 或者NFS 对SAN进行虚拟化管理',' A:提供高性能的文件系统; '),(6,'（ ）不是Swift的设计原则。','A. 负责的算法以提高存储效率','B. 无单点故障','C. 对称的系统架构','D. 数据的持久性',' A:负责的算法以提高存储效率; '),(7,'在互联网的发展过程中，有很多里程碑事件，下列选项中对里程碑事件发生先后顺序排序正常的是（ ）。','A. ARPANET诞生—TCP/IP 建立—DNS诞生—万维网正式向公众开放','B. DNS诞生—TCP/IP建立—ARPANET诞生—万维网正式向公众开放','C. 万维网正式向公众开放—DNS诞生—TCP/IP建立—ARPANET诞生','D. TCP/IP建立—ARPANET诞生—万维网正式向公众开放—DNS 诞生',' A:ARPANET诞生—TCP/IP 建立—DNS诞生—万维网正式向公众开放; '),(8,'以下哪种关于虚拟交换机的说法是错误的？','A. 虚拟交换机利用虚拟化技术，在逻辑上集成多台物理连接的交换机。','B. 使用虚拟交换机能够缩减网络设备数量，简化网络结构。','C. 虚拟机能够进行热迁移的条件之一就是要有分布式虚拟交换机。','D. 虚拟交换机只能运行在一台单独的物理主机上。',' D:虚拟交换机只能运行在一台单独的物理主机上。; '),(9,'以下哪种技术可将一个物理的局域网在逻辑上划分成多个广播域？','A. SNMP','B. VLAN','C. IPSec','D. VPN',' B:VLAN; '),(10,'互联网Internet的拓扑结构是什么？','A. 星型','B. 总线型','C. 网状型','D. 环型',' C:网状型; '),(11,'以下哪种关于分组交换网络的说法是错误的？','A. 分组在分组交换网络中独立地选择路由','B. 分组交换网络在数据通信过程中对通信链路是逐段占用的','C. 分组交换网在传输分组前需事先要建立一条从源到目的的通信链路','D. 分组交换网采用的是存储转发技术',' C:分组交换网在传输分组前需事先要建立一条从源到目的的通信链路; '),(12,'以下哪种关于SDN的说法是错误的？','A. SDN将网络中的数据平面和控制平面分离开来','B. SDN将网络设备的所有控制逻辑集中在中心控制器中','C. 分布式控制模式是SDN的核心理念','D. SDN能实现对网络设备的灵活控制，并能够有效降低设备负载',' C:分布式控制模式是SDN的核心理念; '),(13,'以下哪个不是互联网Internet常用的路由算法？','A. OSPF','B. CSMA/CD','C. RIP','D. BGP',' B:CSMA/CD; '),(14,'以下哪一项效果是VLAN技术不能实现的？','A. 通过软件编程实现对网络设备的灵活控制','B. 增强局域网的安全性','C. 提高了网络的健壮性','D. 限制广播域',' A:通过软件编程实现对网络设备的灵活控制; '),(15,'以下哪一种网络设备是工作在网络层的？','A. 路由器','B. 网桥','C. 交换机','D. 集线器',' A:路由器; '),(16,'以下哪种协议是在TCP/IP模型中的网络层中运行的？','A. IP','B. UDP','C. HTTP','D. TCP',' A:IP; '),(17,'如果一台物理服务器上的多个虚拟机通过华为DVS相连，则分属不同端口组的两个虚拟机通信的流量走向，以下哪些说法是正确的？','A. 访问流量需要从源主机内部传出，但外部可使用二层交换机进行转发','B. 端口组不同无法进行通信','C. 通信直接通过DVS在源主机内部完成，通信的流量不需要传出到外部网络','D. 访问流量需要从源主机内部传出到外部三层交换机并经其转发才能完成通信',' D:访问流量需要从源主机内部传出到外部三层交换机并经其转发才能完成通信; '),(18,'在华为FusionCompute架构中，担任主机角色的是（ ）','A.  UVP','B.  KVM','C.  CNA','D.  VRM',' C:CNA; '),(19,'云用户申请的数字证书中一般不包含以下哪个部分？','A. 云用户私钥','B. 云用户公钥','C. CA认证的云用户的身份数据','D. CA数字签名',' A:云用户私钥; '),(20,'在对消息应用相同哈希算法的前提下，以下哪种关于消息摘要的叙述是正确的？','A. 消息摘要的长度一般与消息相同','B. 相同的消息一定产生相同的摘要','C. 不同消息的摘要一般长度不同','D. 不同的消息一定不会产生相同的摘要',' B:相同的消息一定产生相同的摘要; '),(21,'弹性资源容量架构中通常不包括以下哪个部件？','A. 自动扩展监听器','B. SLA监控代理','C. 资源池','D. 智能自动化引擎脚本',' B:SLA监控代理; '),(22,'以下哪种基本云架构建立了一个动态存储供给系统，确保按照云用户实际使用的存储量进行精确计费？','A. 弹性磁盘供给架构','B. 弹性资源容量架构','C. 动态可扩展架构','D. 服务负载均衡架构',' A:弹性磁盘供给架构; '),(23,'以下哪种不是资源管理系统的主要工作？','A. 管理虚拟IT资源模板，如虚拟服务器映像','B. 在可用的物理基础设施中分配、释放和协调虚拟IT资源','C. 监视IT资源的操作条件，强制执行使用策略与安全规定','D. 管理用户账户、安全凭证、授权和访问控制',' D:管理用户账户、安全凭证、授权和访问控制; '),(24,'以下关于NoSQL数据库的说法哪些是错误的？','A. NoSQL数据库相比关系数据库在大数据环境下具有更好的存储和读写性能','B. NoSQL数据库相比关系数据库更易扩展','C.  NoSQL是指非关系型数据库','D. NoSQL数据库强调数据的规范化，支持事务与连接操作',' D:NoSQL数据库强调数据的规范化，支持事务与连接操作; '),(25,'以下哪个网络存储接口的协议与块存储无关？','A.  FC','B.  iSCSI','C.  NFS','D.  SCSI',' C:NFS; '),(26,'关于加密技术，以下哪些说法是错误的？','A. 非对称加密能提供真实性、不可否认性和完整性保护','B. 相比非对称加密，对称加密计算起来一般较慢','C. 对称加密没有不可否认性','D. 用私钥加密的文档只能用相应的公钥才能正确解密',' B:相比非对称加密，对称加密计算起来一般较慢; '),(27,'以下哪种关于虚拟机监控器（hypervisor）的说法是错误的？','A.  虚拟监控器主要用于创建虚拟服务器实例','B.  虚拟监控器能够配合VIM，利用已存储的虚拟服务器映像来复制虚拟服务器实例','C.  虚拟监控器是运行在物理服务器上的软件','D.  虚拟机监控器是用来控制和管理虚拟服务器的',' A:虚拟监控器主要用于创建虚拟服务器实例; '),(28,'虚拟服务器通常不包含以下哪类IT资源？','A.  外存','B.  内存','C.  CPU 核','D.  外设',' D:外设; '),(29,'多租户技术是云计算的重要支撑技术。以下哪些因素不是多租户应用的一般特点？','A.  可恢复性','B.  使用隔离','C.  可扩展性','D.  可协同性',' D:可协同性; '),(30,'以下哪些服务不属于云计算提供的服务？','A.   IaaS','B.  PaaS','C.  SaaS','D.  RaaS',' D:RaaS; '),(31,'“云计算”名称中的“云”，其渊源来源于以下哪种说法？','A.  云计算某些方面向云一样不可捉摸','B.  用户无法看到云计算中包含的资源，如同隐藏在云的后面','C.  云计算的支撑技术互联网常以一个云状图案来表示，因此提供资源的网络常被成为“云”。','D.  云计算的规模一般像云一样广阔',' C:云计算的支撑技术互联网常以一个云状图案来表示，因此提供资源的网络常被成为“云”。; '),(32,'以下关于资源池化的说法哪些是错误的？','A.  资源池化是实现按需自助服务的前提之一','B.  资源池化需将所有的资源分解到最小单位','C.  资源池化相当于资源归类','D.  资源池化可以屏蔽不同资源的差异性',' C:资源池化相当于资源归类; '),(33,'以下哪一项不是云计算的特点？','A.  快速弹性伸缩','B.  资源互补','C.  按需自助服务','D.  广泛的网络接入',' B:资源互补; '),(34,'关于云计算的计量服务，以下哪些说法是错误的？','A.  使用配额的计费系统，超出配额时会阻止云用户的进一步使用请求。','B.  云计算中的服务都是根据使用时间来进行计量的。','C.  云计算系统中一般都有计费管理系统，专门用于收集和处理使用数据。','D.  计量是计费的基础。',' B:云计算中的服务都是根据使用时间来进行计量的。; '),(35,'以下哪些因素不是云计算技术诞生和发展的主要推动力？','A.  网络带宽的提升','B.  虚拟化技术的出现','C.  深度学习技术的出现','D.  移动互联网的发展',' C:深度学习技术的出现; '),(36,'以下哪种服务与云计算无关？','A.  Zoom 会议系统','B.  有道云笔记','C.  百度网盘','D.  超级计算机的远程登录系统',' D:超级计算机的远程登录系统; '),(37,'关于云计算的快速弹性伸缩，以下哪些说法是错误的？','A.  快速弹性伸缩必须人为手动扩容或减容。','B.  弹性化扩张能力被认为是吸引用户拥抱云计算的核心理由之一。','C.  快速弹性伸缩能使用户在保证业务或者应用稳定运行的前提下节省成本。','D.  快速弹性伸缩是指云用户可以根据自己的需要，自动透明地扩展IT资源。',' A:快速弹性伸缩必须人为手动扩容或减容。; '),(38,'云计算带来的好处不包括：','A.  数据可以随时随地即时访问','B.  增强了对用户隐私的保护','C.  提高适应能力，灵活扩展IT需求','D.  节省成本',' B:增强了对用户隐私的保护; ');
/*!40000 ALTER TABLE `one` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `three`
--

DROP TABLE IF EXISTS `three`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `three` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(600) NOT NULL,
  `an` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `three`
--

LOCK TABLES `three` WRITE;
/*!40000 ALTER TABLE `three` DISABLE KEYS */;
INSERT INTO `three` (`id`, `title`, `an`) VALUES (1,'7. OpenStack是一个自由和开放源代码的平台，主要是用于部署&&。','(1) 云基础设施'),(2,'8. OpenStack是构建&&的框架，通过集成管理各类硬件设备，并承载各类上层应用与服务，最终形成一个完整系统。','(1) 云操作系统'),(3,'9. 最初，OpenStack中的网络服务由Nova中一个单独的模块&&来提供。','(1) Nova-network'),(4,'10. OpenStack包含的核心组件是&、&&、&、&&、&&。','(1) Nova(2) Swift(3) Glance(4) Keystone(5) Neutron'),(5,'11. &&作为OpenStack中的一个独立的提供安全认证的模块，主要负责OpenStack用户的身份认证、令牌管理、提供访问资源的服务目录，以及基于用户角色的访问控制。','(1) Keystone'),(6,'11. 某主机的IP地址192.168.1.11，子网掩码为255.255.255.248，则该主机所在子网的网络地址是&&&。','(1) 192.168.1.8'),(7,'12. 计算机之间要通信，要交换信息，彼此就需要有某些约定和规则，这些约定和规则就是&&&。','(1) 网络协议'),(8,'13. 组建计算机网络的主要目的是&&&和实现数据通信。','(1) 资源共享'),(9,'14. 计算机网络按应用类型可分为&&&、&&&和互联网三类。','(1) 内联网;Intranet(2) 外联网;Extranet]'),(10,'15. &&&是一种新型网络创新架构，可通过软件编程的形式定义和控制网络。','(1) 软件定义网络;SDN'),(11,'16. &&&是工作在数据链路层的网络设备，其特点是可以为接入该设备的任意两个网络节点提供独享的电信号通路，这也是它与集线器的显著区别。','(1) 交换机'),(12,'17. 以太网的MAC帧，帧结构中通常包含目的地址、&&&、类型字段、帧数据及校验字段这些字段。','(1) 源地址'),(13,'18. 网络按地理位置覆盖范围分为&&&、&&&和&&&。','(1) 局域网;LAN(2) 城域网;MAN(3) 广域网;WAN'),(14,'19. 计算机网络时&&&与&&&密切结合的产物。','(1) 计算机技术(2) 通信技术'),(15,'20. &&是利用公用网络架设安全的专用网络，其功能包括认证、加密、隧道化及防火墙功能。','(1) 虚拟专用网;VPN'),(16,'11. 与云存储相关的主要问题是数据的安全性、&&和保密性。','(1) 完整性'),(17,'12. &&&将一组相关的基于云的IT资源与云中的其他主体（如非授权用户）隔离开来，其主要功能是网络分段和隔离，以保证区域内的IT设施的相对独立性。','(1) 逻辑网络边界'),(18,'13. &&建立了一种动态扩展的形式，只要达到预先设置的容量阀值，就从企业内部的IT资源扩展或“爆发”到云中。','(1) 云爆发架构'),(19,'14. &是关于网络服务供应商和客户间的一份合同，其中定义了服务类型、服务质量和客户付款等术语。','(1) SLA；服务等级协议'),(20,'15. &&机制能帮助云用户为其提供跨越多个云服务的认证和授权信息服务，即实现单次认证，多处访问。','(1) 单一登录；单点登录；SSO'),(21,'16. 云存储设备按数据存储等级来分可分为四类：文件、块、数据集和&&。','(1) 对象'),(22,'11. &&技术是云计算的基础支撑。云时刻都离不开&&网络。','(1) 网络；互联网(2) 互联网'),(23,'12. 为云服务提供网络接入服务的互联网服务提供商的英文简称为&&。','(1) ISP'),(24,'13. 云计算技术将计算资源、&&&以及其他各类资源通过网络以服务的形式提供给资源用户。','(1) 存储资源'),(25,'14. &&以服务形式提供基于服务器和存储等硬件资源的可高度扩展和按需变化的IT能力。通常按照所消耗资源的成本进行收费。','(1) IaaS；基础设施即服务'),(26,'15. 按照云计算的运营模式分类，云可以分为&&、&&、社区云、混合云和行业云等。','(1) 公有云(2) 私有云'),(27,'16. &&位于云计算三层服务的中间，通常也称为“云操作系统”，提供给终端用户基于互联网的应用开发环境，包括应用编程接口和运行平台等。','(1) PaaS；平台即服务');
/*!40000 ALTER TABLE `three` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two`
--

DROP TABLE IF EXISTS `two`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `A` varchar(256) NOT NULL,
  `B` varchar(256) NOT NULL,
  `C` varchar(256) NOT NULL,
  `D` varchar(256) NOT NULL,
  `an` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two`
--

LOCK TABLES `two` WRITE;
/*!40000 ALTER TABLE `two` DISABLE KEYS */;
INSERT INTO `two` (`id`, `title`, `A`, `B`, `C`, `D`, `an`) VALUES (1,'以下关于云计算描述正确的是（ ）。','A. 在云计算中获取的IT资源需要通过网络才能使用','B. 云计算是一种技术，能够实现随时随地、便捷地、随需应变地获取到IT资源','C. 云计算中的各种IT资源需要付费才能使用','D. 在获取IT资源的过程中，用户需要与云计算服务提供商反复交涉',' AC:在云计算中获取的IT资源需要通过网络才能使用; 云计算中的各种IT资源需要付费才能使用; '),(2,'以下描述能体现虚拟化优势的是（ ）','A. 使用虚拟化后，一台物理主机的操作系统上可以同时运行多个应用程序','B. 使用虚拟化后，一台物理主机上可以同时运行多台虚拟机','C. 使用虚拟化后，虚拟机可以在多台主机间进行迁移','D. 使用虚拟化后，一台物理主机的CPU利用率可以稳定在65%左右',' BC:使用虚拟化后，一台物理主机上可以同时运行多台虚拟机; 使用虚拟化后，虚拟机可以在多台主机间进行迁移; ');
/*!40000 ALTER TABLE `two` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-25 15:41:53
